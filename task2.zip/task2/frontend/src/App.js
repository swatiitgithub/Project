import logo from './logo.svg';
import './App.css';
import Tdatashow from './tdatashow';

function App() {
  return (
    <div className="App">
      <Tdatashow />
    </div>
  );
}

export default App;
