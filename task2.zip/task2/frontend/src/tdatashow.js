import React, { useEffect, useState } from 'react';
import axios from 'axios';


function Tdatashow() {
    const [data, setData] = useState([]);

    useEffect(() => {
        getData();
    }, []);

    const getData = async () => {
        try {
            const url = "http://localhost:4500/tdata/ticketdata";
            const headers = {
                "Content-Type": "application/json",
                Accept: "application/json",
            };
            const response = await axios.get(url, { headers });
            const topTenData = response.data.slice(0, 10); // Get the first 10 elements
            setData(topTenData);
        } catch (error) {
            console.error("Error connecting to API", error);
        }
    };

    return (
        <>
            <div className='bg-danger' style={{ height: "40px" }}>
                <table className="table">
                    <thead>
                        <tr>
                            <th scope="col">Sr. No</th>
                            <th scope="col">Base Unit</th>
                            <th scope="col">Quote Unit</th>
                            <th scope="col">Low</th>
                            <th scope="col">High</th>
                            <th scope="col">Last</th>
                            <th scope="col">Type</th>
                            <th scope="col">Open</th>
                            <th scope="col">Volume</th>
                            <th scope="col">Sell</th>
                            <th scope="col">Buy</th>
                            <th scope="col">At</th>
                            <th scope="col">Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map((item, index) => (
                            <tr key={index}>
                                <td>{index + 1}</td>
                                <td>{item.base_unit}</td>
                                <td>{item.quote_unit}</td>
                                <td>{item.low}</td>
                                <td>{item.high}</td>
                                <td>{item.last}</td>
                                <td>{item.type}</td>
                                <td>{item.open}</td>
                                <td>{item.volume}</td>
                                <td>{item.sell}</td>
                                <td>{item.buy}</td>
                                <td>{item.at}</td>
                                <td>{item.name}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>

            </div>

        </>
    );
}

export default Tdatashow;
