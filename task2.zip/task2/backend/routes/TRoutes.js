// routes/index.js

const express = require('express');
const router = express.Router();
const tickerController = require('../controller/Tcontroller.js');
const Ticketdata = require('../controller/getticketdata.js');

router.get('/tget', tickerController.fetchAndStoreTickerData);
router.get("/ticketdata", Ticketdata);

module.exports = router;
