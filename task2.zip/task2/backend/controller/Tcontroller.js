// controllers/tickerController.js

const axios = require('axios');
const Ticker = require('../models/Tmodel.js');

async function fetchAndStoreTickerData(req, res) {
    try {
        const response = await axios.get('https://api.wazirx.com/api/v2/tickers');
        const tickersData = response.data;

        for (const tickerSymbol in tickersData) {
            const ticker = new Ticker(tickersData[tickerSymbol]);
            await ticker.save();
            // console.log(`Stored data for ${tickerSymbol}`);
        }

        res.status(200).json({ "status_code": "200", "message": 'All data stored successfully' });
    } catch (error) {
        console.error('Error fetching and storing data:', error.message);
        res.status(500).json({ error: 'Something went wrong' });
    }
}

module.exports = {
    fetchAndStoreTickerData
};
