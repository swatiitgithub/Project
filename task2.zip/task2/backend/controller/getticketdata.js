const Ticker = require('../models/Tmodel.js');
const mongoose = require('mongoose');

GetTicketData = async (req, res) => {
    try {

        const getticketdetails = await Ticker.find();
        res.json(getticketdetails);
    } catch (error) {
        console.log("error", error);
    }

}
module.exports = GetTicketData;