const express = require('express');
const cors = require('cors');
require('./db/conn');
const Trouter = require('./routes/TRoutes.js');

const app = express();
app.use(cors());

app.use(express.json());
const port = process.env.PORT || 4500;

app.use('/tdata', Trouter);


app.listen(port, () => {
    console.log("Connection is established successfully...");
});
